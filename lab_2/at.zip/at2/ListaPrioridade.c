#include "listaprioridade.h"
#include <stdlib.h>
#include <stdio.h>

void criaLista(ListaPrioridade *lista, int tamanhoMaximo)
{

    lista->tamanhoMaximo = tamanhoMaximo;
    lista->pessoas = (Pessoa *)malloc(sizeof(Pessoa) * tamanhoMaximo);
    lista->primeiro = 0;
    lista->ultimo = -1;
}

int VerificaListaVazia(ListaPrioridade *lista)
{

    if (lista->ultimo == -1)
    {
        return 1;
    }
    return 0;
}

int insereNovaPessoaNoFinal(ListaPrioridade *lista, Pessoa pessoa)
{

    if (lista->ultimo == lista->tamanhoMaximo)
    {
        return 0;
    }

    lista->ultimo++;

    lista->pessoas[lista->ultimo] = pessoa;

    printf("%s adicionada com prioridade %d\n", lista->pessoas[lista->ultimo].nome, lista->pessoas[lista->ultimo].prioridade);

    return 1;
}

int chamaProximaPessoa(ListaPrioridade *lista)
{
    

    int indice = 0;
    int prioridade = 0;

    for (int i = 0; i <= lista->ultimo; i++)
    {

        if (lista->pessoas[i].prioridade > prioridade)
        {

            prioridade = lista->pessoas[i].prioridade;
            indice = i;
        }
    }

    printf("Proximo: %s, %d\n", lista->pessoas[indice].nome, prioridade);

    while (indice < lista->ultimo)
    {

        lista->pessoas[indice] = lista->pessoas[indice + 1];
        indice++;
    }

    lista->ultimo--;
}

void imprimeLista(ListaPrioridade *lista)
{

    if (lista->ultimo == -1)
    {
        printf("Lista vazia\n");
    }
    else
    {

        for (int i = 0; i <= lista->ultimo; i++)
        {
            printf("%s, %d\n", lista->pessoas[i].nome, lista->pessoas[i].prioridade);
        }
    }
}